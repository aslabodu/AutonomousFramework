#pragma once

#include <iostream>
#include "OGL_header.h"

class Rover;
class Environment;

class Simulation
{
public:
	Simulation();
	~Simulation();	

	// InitializeSimulaton
	// --- Runs initialization for OpenGL and creates the initial scene.
	// --- Params:	argc - number of program arguments
	//				argv - program arguments
	void InitializeSimulation(int argc, char** argv);
	
	// Run
	// --- Starts the OpenGL main loop
	void Run();

	// Update
	// --- Called based on fixed time interval given in SetClock(). Allows for scene objects to update.
	void Update();

	// Draw
	// --- Called on OpenGL redisplay.  Allows for scene objects to render to screen.
	void Draw();

	// Keyboard
	// --- OpenGL keyboard callback for when a key is pressed.
	// --- Params:	key - the ASCII character pressed
	//				x - current X coord of the cursor relative to the window
	//				y - current Y coord of the cursor relative to the window
	void Keyboard(unsigned char key, int x, int y);

	// SpecialKey
	// --- OpenGL keyboard callback for special characters.
	// --- Params:	key - the OpenGL id for the key pressed. See www.opengl.org/resources/libraries/glut/spec3/node54.html.
	//				x - current X coord of the cursor relative to the window
	//				y - current Y coord of the cursor relative to the window
	void SpecialKey(int key, int x, int y);

	// MouseMove
	// --- OpenGL callback for handling mouse movement when mouse button is pressed.
	// --- Params:	x - current X coord of the cursor relative to the window
	//				y - current Y coord of the cursor relative to the window
	//				
	void MouseMove(int x, int y);

	// PassiveMouseMove
	// --- OpenGL callback for handling mouse movement without mouse button press.
	// --- Params:	x - current X coord of the cursor relative to the window
	//				y - current Y coord of the cursor relative to the window
	//			
	void PassiveMouseMove(int x, int y);


	// Reshape
	// --- OpenGL callback for handling resizing of the window
	// --- Params:	w - current width of the window
	//				h - current height of the window
	//		
	void Reshape(int w, int h);

	void SetWindowPosition(int x, int y);
	void SetWindowSize(int width, int height);
	void SetClock(int timer);
	void SetTitle(std::string title);

	GLuint WindowWidth();
	GLuint WindowHeight();

	Environment* GetEnvironment();

private:
	int positionX, positionY, width, height;
	int timer;
	bool timerSet;
	std::string title;

	Rover* rover;
	Environment* env;

	// InitializeGraphics
	// --- Performs setup of window and initial OpenGL settings
	//		
	void InitializeGraphics();

	// InitScene
	// --- Performs setup of objects necessary to construct the scene
	//		
	void InitScene();

	// InitScene
	// --- Registers callback functions with OpenGL main loop.
	//	
	void RegisterCallbacks();

	// glEnable2D
	// --- Sets up orthographic view and viewport based on current width and height
	//	
	void glEnable2D();

	// glDisable2D
	// --- Resets OpenGL view to settings set through glEnable2D()
	//	
	void glDisable2D();
};

