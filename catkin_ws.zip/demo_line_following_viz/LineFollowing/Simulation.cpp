#include "Simulation.h"
#include "Rover.h"
#include "Environment.h"

Simulation* simulation;

void display()
{
	simulation->Draw();
}

void reshape(int w, int h)
{
	simulation->Reshape(w, h);
}

void keyboard(unsigned char key, int x, int y)
{
	simulation->Keyboard(key, x, y);
	glutPostRedisplay();
}

void specialKey(int key, int x, int y)
{
	simulation->SpecialKey(key, x, y);
	glutPostRedisplay();
}

void mouseMove(int x, int y)
{
	simulation->MouseMove(x, y);
	glutPostRedisplay();
}

void passiveMouseMove(int x, int y)
{
	simulation->PassiveMouseMove(x, y);
	glutPostRedisplay();
}

void clock(int time)
{
	simulation->Update();
	glutTimerFunc(time, clock, time);
	glutPostRedisplay();
}


Simulation::Simulation()
{
}

Simulation::~Simulation()
{
}

void Simulation::SetWindowPosition(int x, int y)
{
	this->positionX = x;
	this->positionY = y;
}

void Simulation::SetWindowSize(int width, int height)
{
	this->width = width;
	this->height = height;
}

void Simulation::SetClock(int timer)
{
	this->timer = timer;
	timerSet = true;
}

void Simulation::SetTitle(std::string title)
{
	this->title = title;
}

GLuint Simulation::WindowWidth()
{
	return width;
}

GLuint Simulation::WindowHeight()
{
	return height;
}

Environment * Simulation::GetEnvironment()
{
	return env;
}

void Simulation::RegisterCallbacks()
{
	::simulation = this;
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(specialKey);
	glutMotionFunc(::mouseMove);
	::glutPassiveMotionFunc(::passiveMouseMove);

	if (timerSet)
		glutTimerFunc(timer, clock, timer);
}

void Simulation::InitializeSimulation(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	InitializeGraphics();
	InitScene();
}

void Simulation::InitializeGraphics()
{
	glutInitWindowPosition(positionX, positionY);
	glutInitWindowSize(width, height);
	glutCreateWindow(title.c_str());
	//glewInit();
	
	glDisable(GL_DITHER);	// Disable dithering	
	glDisable(GL_BLEND);	// Disable blending (for now)	
	glDisable(GL_DEPTH_TEST); // Disable depth testing
}

void Simulation::glEnable2D()
{
	glViewport(0, 0, width, height);

	GLint iViewport[4];

	// Get a copy of the viewport
	glGetIntegerv(GL_VIEWPORT, iViewport);

	// Save a copy of the projection matrix so that we can restore it 
	// when it's time to do 3D rendering again.
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();

	// Set up the orthographic projection
	glOrtho(iViewport[0], iViewport[0] + iViewport[2], iViewport[1] + iViewport[3], iViewport[1], -1, 1);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	// Make sure depth testing and lighting are disabled for 2D rendering until
	// we are finished rendering in 2D
	glPushAttrib(GL_DEPTH_BUFFER_BIT | GL_LIGHTING_BIT);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
}

void Simulation::glDisable2D()
{
	glPopAttrib();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

void Simulation::InitScene()
{
	// Load Scene Objects....
	rover = new Rover(this);
	env = new Environment(this);
}

void Simulation::Update()
{
	rover->Update(timer / 1000.0f);
}

void Simulation::Draw()
{
	glEnable2D();

	// Clear scene
	glClearColor(0.5f, 0.5f, 0.5f, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glLoadIdentity();

	env->Draw();
	rover->Draw();	

	glutSwapBuffers();
	glFlush();

	glDisable2D();
}

void Simulation::Run()
{
	RegisterCallbacks();
	glutMainLoop();
}

void Simulation::Keyboard(unsigned char key, int x, int y)
{

}

void Simulation::SpecialKey(int key, int x, int y)
{

}

void Simulation::MouseMove(int x, int y)
{

}

void Simulation::PassiveMouseMove(int x, int y)
{

}

void Simulation::Reshape(int w, int h)
{
	this->width = w;
	this->height = h;
}



