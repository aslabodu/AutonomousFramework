#include "Environment.h"

Environment::Environment(Simulation* sim)
{
	_sim = sim;

	LoadImage("..//Assets//Env2.bmp");

	i0[0] = 0;
	i0[1] = 0;
	i1[0] = 0;
	i1[1] = 0;
	i2[0] = 0;
	i2[1] = 0;
	i3[0] = 0;
	i3[1] = 0;
	i4[0] = 0;
	i4[1] = 0;
}

void Environment::LoadImage(std::string textureFile)
{
	// Load texture info
	image = new BMP(textureFile.c_str());

	// Enable the texture rectangle extension
	glEnable(GL_TEXTURE_2D);

	// Generate one texture ID
	glGenTextures(1, &texture);

	// Bind the texture using GL_TEXTURE_2D
	glBindTexture(GL_TEXTURE_2D, texture);

	// Enable bilinear filtering on this texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// Write the 32-bit RGBA texture buffer to video memory
	glTexImage2D(GL_TEXTURE_2D, 0, image->HasAlphaChannel() ? GL_RGBA : GL_RGB, image->GetWidth(), image->GetHeight(),
				 0, image->HasAlphaChannel() ? GL_BGRA_EXT : GL_BGR_EXT, GL_UNSIGNED_BYTE, image->GetPixels().data());

	// Save a copy of the texture's dimensions for later use
	textureWidth = image->GetWidth();
	textureHeight = image->GetHeight();
}


// CheckForLine
// ---	Note the algorithm assumes that there are only 5 sensor points to construct. 
//		Points are constructed by first computing the middle point based on x,y,theta, and offset.
//		The other four points are computed by offsetting from the middle point
//		The positions are used to index (as integers) into the texture image and obtain color information.
//		Only one channel is checked.  If channel is value 255, array element is set to True; otherwise it is False.
//		If position is outside image area, array element is set to False.
void Environment::CheckForLine(float x, float y, float theta, float offset, float width, bool* sensorArray)
{
	// calculate middle point position
	p2[0] = x + sin(theta * M_PI / 180.0f) * offset;
	p2[1] = y - cos(theta * M_PI / 180.0f) * offset;
	i2[0] = GLint(p2[0]);
	i2[1] = GLint(p2[1]);

	// calculate 2nd point position
	p1[0] = p2[0] + sin((theta - 90) * M_PI / 180.0f) * width;
	p1[1] = p2[1] - cos((theta - 90) * M_PI / 180.0f) * width;
	i1[0] = GLint(p1[0]);
	i1[1] = GLint(p1[1]);

	// calculate 1st point position
	p0[0] = p2[0] + sin((theta - 90) * M_PI / 180.0f) * width * 2;
	p0[1] = p2[1] - cos((theta - 90) * M_PI / 180.0f) * width * 2;
	i0[0] = GLint(p0[0]);
	i0[1] = GLint(p0[1]);

	// calculate 4th point position
	p3[0] = p2[0] + sin((theta + 90) * M_PI / 180.0f) * width;
	p3[1] = p2[1] - cos((theta + 90) * M_PI / 180.0f) * width;
	i3[0] = GLint(p3[0]);
	i3[1] = GLint(p3[1]);

	// calculate 5th point position
	p4[0] = p2[0] + sin((theta + 90) * M_PI / 180.0f) * width * 2;
	p4[1] = p2[1] - cos((theta + 90) * M_PI / 180.0f) * width * 2;
	i4[0] = GLint(p4[0]);
	i4[1] = GLint(p4[1]);


	// index 1st point in texture and check presence of line
	if (i0[0] > 0 && i0[0] < textureWidth && i0[1] > 0 && i0[1] < textureHeight)
	{
		int index = (i0[0] * 3) + (textureHeight - i0[1]) * (textureWidth * 3);
		uint8_t b = image->GetPixels()[index];
		if (b == 255)
			sensorArray[0] = false;
		else
			sensorArray[0] = true;
	}
	else
	{
		sensorArray[0] = false;
	}

	// index 2nd point in texture and check presence of line
	if (i1[0] > 0 && i1[0] < textureWidth && i1[1] > 0 && i1[1] < textureHeight)
	{
		int index = (i1[0] * 3) + (textureHeight - i1[1]) * (textureWidth * 3);
		uint8_t b = image->GetPixels()[index];
		if (b == 255)
			sensorArray[1] = false;
		else
			sensorArray[1] = true;
	}
	else
	{
		sensorArray[1] = false;
	}

	// index middle point in texture and check presence of line
	if (i2[0] > 0 && i2[0] < textureWidth && i2[1] > 0 && i2[1] < textureHeight)
	{
		int index = (i2[0] * 3) + (textureHeight - i2[1]) * (textureWidth * 3);
		uint8_t b = image->GetPixels()[index];
		if(b == 255)
			sensorArray[2] = false;
		else
			sensorArray[2] = true;
	}
	else
	{
		sensorArray[2] = false;
	}

	// index 4th point in texture and check presence of line
	if (i3[0] > 0 && i3[0] < textureWidth && i3[1] > 0 && i3[1] < textureHeight)
	{
		int index = (i3[0] * 3) + (textureHeight - i3[1]) * (textureWidth * 3);
		uint8_t b = image->GetPixels()[index];
		if (b == 255)
			sensorArray[3] = false;
		else
			sensorArray[3] = true;
	}
	else
	{
		sensorArray[3] = false;
	}

	// index 5th point in texture and check presence of line
	if (i4[0] > 0 && i4[0] < textureWidth && i4[1] > 0 && i4[1] < textureHeight)
	{
		int index = (i4[0] * 3) + (textureHeight - i4[1]) * (textureWidth * 3);
		uint8_t b = image->GetPixels()[index];
		if (b == 255)
			sensorArray[4] = false;
		else
			sensorArray[4] = true;
	}
	else
	{
		sensorArray[4] = false;
	}
}



// Draw
// ---	Draws the environment image and 5 sensor array points
void Environment::Draw()
{
	// Set the primitive color
	glColor3f(1.0f, 1.0f, 1.0f);

	
	// --------- Draw Environment quad ---------- //	
	glBindTexture(GL_TEXTURE_2D, texture);	

	glPushMatrix();

	// transform to center on screen
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	
	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(textureWidth, 0);
		glTexCoord2i(1, 0);
		glVertex2i(textureWidth, textureHeight);
		glTexCoord2i(0, 0);
		glVertex2i(0, textureHeight);
	glEnd();

	glPopMatrix();

	// --------- Draw Sensor points ---------- //
	glColor3f(1.0f, 0.0f, 0.0f);		
	
	// ---- 1st Sensor Point ---- //
	glPushMatrix();
	glTranslatef(i0[0], i0[1], 0.0f);
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	glScalef(0.5f, 0.5f, 0.5f);

	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(5, 0);
		glTexCoord2i(1, 0);
		glVertex2i(5, 5);
		glTexCoord2i(0, 0);
		glVertex2i(0, 5);
	glEnd();
	glPopMatrix();


	// ---- 2nd Sensor Point ---- //	
	glPushMatrix();
	glTranslatef(i1[0], i1[1], 0.0f);
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	glScalef(0.5f, 0.5f, 0.5f);

	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(5, 0);
		glTexCoord2i(1, 0);
		glVertex2i(5, 5);
		glTexCoord2i(0, 0);
		glVertex2i(0, 5);
	glEnd();
	glPopMatrix();


	// ---- Middle Sensor Point ---- //
	glPushMatrix();
	glTranslatef(i2[0], i2[1], 0.0f);
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	glScalef(0.5f, 0.5f, 0.5f);

	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(5, 0);
		glTexCoord2i(1, 0);
		glVertex2i(5, 5);
		glTexCoord2i(0, 0);
		glVertex2i(0, 5);
	glEnd();
	glPopMatrix();
	

	// ---- 4th Sensor Point ---- //	
	glPushMatrix();
	glTranslatef(i3[0], i3[1], 0.0f);
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	glScalef(0.5f, 0.5f, 0.5f);

	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(5, 0);
		glTexCoord2i(1, 0);
		glVertex2i(5, 5);
		glTexCoord2i(0, 0);
		glVertex2i(0, 5);
	glEnd();
	glPopMatrix();
	

	// ---- 5th Sensor Point ---- //
	glPushMatrix();
	glTranslatef(i4[0], i4[1], 0.0f);	
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);	
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);
	glScalef(0.5f, 0.5f, 0.5f);	

	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(5, 0);
		glTexCoord2i(1, 0);
		glVertex2i(5, 5);
		glTexCoord2i(0, 0);
		glVertex2i(0, 5);
	glEnd();
	glPopMatrix();
}

GLuint Environment::Width()
{
	return textureWidth;
}

GLuint Environment::Height()
{
	return textureHeight;
}
