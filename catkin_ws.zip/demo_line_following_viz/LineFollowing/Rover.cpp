#include "Rover.h"
#include "Environment.h"

Rover::Rover(Simulation* sim)
{
	_sim = sim;

	LoadImage("..//Assets//Rover2.bmp");
	_x = 0.0f;
	_y = 0.0f;
	_theta = 125.0f;
	_scale = 1.0f;
	_full_translation_speed = 10.0f;
	_full_rotation_speed = 15.0f;
	_sensorDistance = textureHeight * _scale / 2.0f;
	_sensorWidth = textureWidth / 20.0f;
}

void Rover::LoadImage(std::string textureFile)
{
	// Load texture info
	BMP info = BMP(textureFile.c_str());

	// Enable the texture rectangle extension
	glEnable(GL_TEXTURE_2D);

	// Generate one texture ID
	glGenTextures(1, &texture);

	// Bind the texture using GL_TEXTURE_RECTANGLE_NV
	glBindTexture(GL_TEXTURE_2D, texture);

	// Enable bilinear filtering on this texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// Write the 32-bit RGBA texture buffer to video memory
	glTexImage2D(GL_TEXTURE_2D, 0, info.HasAlphaChannel() ? GL_RGBA : GL_RGB, info.GetWidth(), info.GetHeight(),
				 0, info.HasAlphaChannel() ? GL_BGRA_EXT : GL_BGR_EXT, GL_UNSIGNED_BYTE, info.GetPixels().data());

	// Save a copy of the texture's dimensions for later use
	textureWidth = info.GetWidth();
	textureHeight = info.GetHeight();
}

void Rover::Control(int leftWheel, int rightWheel)
{
	_leftWheel = leftWheel;
	_rightWheel = rightWheel;
}

// Rotate
// ---	Rotation is applied only if left and right wheel settings are NOT equal.
//		Direction of rotation is based on which wheel is set higher. CW -> Left higher, CCW -> Right higher
//		Rotation speed is based on difference between settings.  Full speed -> Diff of 2, Half speed -> Diff of 1
//
void Rover::Rotate(double elapsedTime)
{
	if (_leftWheel != _rightWheel)
	{
		int direction = (_leftWheel > _rightWheel) ? 1 : -1;
		float speed = (abs(_leftWheel - _rightWheel) > 1) ? _full_rotation_speed : _full_rotation_speed / 2;
		float angleToApply = speed * elapsedTime * direction;

		float _rotX;
		float _rotY;

		// Define local axis of rotation for each wheel
		if (direction == 1)			// Axis passing through Right wheel 
		{
			_rotX = 24.0f;
			_rotY = -8.0f;
		}
		else if (direction == -1)	// Axis passing through Left wheel 
		{
			_rotX = -24.0f;
			_rotY = -8.0f;
		}

		// Transform axis into world coordinates....
		float c = cos(_theta * M_PI / 180.0f);
		float s = sin(_theta * M_PI / 180.0f);
		float t_rotX = c * _rotX - s * _rotY;
		float t_rotY = s * _rotX + c * _rotY;
		t_rotX += _x;
		t_rotY += _y;

		// --- Apply Rotation to Theta and X, Y coordinates --- //

		// angle to apply		
		c = cos(angleToApply * M_PI / 180.0f);
		s = sin(angleToApply * M_PI / 180.0f);

		// transform to origin
		_x = _x - t_rotX;
		_y = _y - t_rotY;

		// apply rotation
		float tx = c * _x - s * _y;
		float ty = s * _x + c * _y;

		// transform back
		_x = tx + t_rotX;
		_y = ty + t_rotY;

		// update orientation
		_theta = _theta + angleToApply;
	}
}

// Translation
// ---	Translation is only applied if both wheels are NOT 0 (i.e. both wheels are turning).
//		Direction of translation is based on current orientation (theta angle). Note that rotation is applied first in Update()
//		Translation speed is based on wheel is the MAXIMUM setting.  If max is 1, speed is half. If max is 2, speed is full.
//
void Rover::Translate(double elapsedTime)
{
	if (_leftWheel != 0 && _rightWheel != 0)
	{
		GLfloat moveVec[2];
		moveVec[0] = sin(_theta * M_PI / 180.0f);
		moveVec[1] = -cos(_theta * M_PI / 180.0f);

		float speed = 0;

		int maxWheel = (_leftWheel > _rightWheel) ? _leftWheel : _rightWheel;
		
		if (maxWheel == 1)
			speed = _full_translation_speed / 2;
		else if (maxWheel == 2)
			speed = _full_translation_speed;

		_x = _x + moveVec[0] * speed * elapsedTime;
		_y = _y + moveVec[1] * speed * elapsedTime;
	}
}

void Rover::Update(double elapsedTime)
{
	bool sensorArray[5];	
	_sim->GetEnvironment()->CheckForLine(_x, _y, _theta, _sensorDistance, _sensorWidth, sensorArray);
	printf("%i|%i|%i|%i|%i\n", sensorArray[0], sensorArray[1], sensorArray[2], sensorArray[3], sensorArray[4]);

	Respond(sensorArray[0], sensorArray[1], sensorArray[2], sensorArray[3], sensorArray[4]);

	Rotate(elapsedTime);
	Translate(elapsedTime);
}

void Rover::Draw()
{
	//// Blend the color key into oblivion! (optional)
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Set the primitive color
	glColor3f(1.0f, 1.0f, 1.0f);

	// Bind the texture to the polygons
	glBindTexture(GL_TEXTURE_2D, texture);

	glPushMatrix();

	// transform based on X,Y position
	glTranslatef(_x, _y, 0.0f);

	// transform to center on screen (applied second)
	glTranslatef(_sim->WindowWidth() / 2.0f, _sim->WindowHeight() / 2.0f, 0.0f);		
	glTranslatef(_sim->GetEnvironment()->Width() / -2.0f, _sim->GetEnvironment()->Height() / -2.0f, 0.0f);

	// transform to center quad (applied first)
	glRotatef(_theta, 0.0f, 0.0f, 1.0f);	
	glScalef(_scale, _scale, 0.0f);	
	glTranslatef(textureWidth / -2.0f, textureHeight / -2.0f, 0.0f);

	// Render a quad
	glBegin(GL_QUADS);
		glTexCoord2i(0, 1);
		glVertex2i(0, 0);
		glTexCoord2i(1, 1);
		glVertex2i(textureWidth, 0);
		glTexCoord2i(1, 0);
		glVertex2i(textureWidth, textureHeight);
		glTexCoord2i(0, 0);
		glVertex2i(0, textureHeight);
	glEnd();

	glPopMatrix();

	glDisable(GL_BLEND);
}

void Rover::Respond(bool sensor1, bool sensor2, bool sensor3, bool sensor4, bool sensor5)
{
	// -------- Insert code to affect control here --------------
	static bool hitLine = false;

	if (!hitLine && (sensor1 || sensor2 || sensor3 || sensor4 || sensor5))
		hitLine = true;

	if(sensor3 || !hitLine)
		Control(2, 2);

	if (sensor1)
		Control(0, 2);

	if (sensor2)
		Control(1, 2);

	if (sensor4)
		Control(2, 1);

	if (sensor5)
		Control(2, 0);
	// ----------------------------------------------------------------
}





