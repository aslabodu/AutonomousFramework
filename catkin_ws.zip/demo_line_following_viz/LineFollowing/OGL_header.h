#ifndef _OPENGL_HEADERS_
#define _OPENGL_HEADERS_

#include <string>
//#include "GL/glew.h"
#include "GL/glut.h"

#define M_PI 3.1415926535897932384626433832795

#endif // _OPENGL_HEADERS_