#pragma once
#include "OGL_header.h"
#include "Simulation.h"
#include "Environment.h"
#include "BMP.h"

class Rover
{

private:
	int _leftWheel;
	int _rightWheel;
	float _x;
	float _y;
	float _theta;
	float _scale;
	float _sensorDistance;
	float _sensorWidth;
	float _full_translation_speed;
	float _full_rotation_speed;


	GLuint texture;
	GLuint textureWidth;
	GLuint textureHeight;

	GLuint envWidth;
	GLuint envHeight;

	Simulation* _sim;

public:
	
	Rover(Simulation* sim);

	// Update
	// --- Obtains new sensor data from environment and compute new position and orientation based on current wheel settings.
	// --- Params: elapsedTime - time since last update in seconds.
	void Update(double elapsedTime);

	// Draw
	// --- Renders the loaded image on the screen based on current position and orientation.
	void Draw();


private:
	
	// LoadImage
	// --- Attempts to load the given texture image file in BMP format.  Does not check for errors. Any errors are handled by BMP class. Also, sets texture width and height to the size of the loaded texture
	// --- Params: textureFile - Absolute or relative path to the image file. Note relative to current working directory.
	void LoadImage(std::string textureFile);

	// Respond
	// --- Planning method to change control state based on given sensor array data. Assumes 5 sensor elements
	// --- params: sensor1 <-> sensor5 - sensor array data.  True indicates presence of a line.  False indicates absence.
	void Respond(bool sensor1, bool sensor2, bool sensor3, bool sensor4, bool sensor5);

	// Control 
	// --- Sets the control state of the rover wheels to affect their individual speed. Only certain values are valid. Any other values may result in undefined behavior.
	// --- Params:	leftWheel - Controls the speed of left wheel. 0 = stopped, 1 = half-speed, 2 = full-speed
	//				rightWheel - Controls the speed of right wheel. 0 = stopped, 1 = half-speed, 2 = full-speed
	void Control(int leftWheel, int rightWheel);

	// Rotate
	// --- Changes the orientation of the rover based on the left and right wheel settings.
	// --- Param: elapsedTime - time since last update in seconds.
	void Rotate(double elapsedTime);

	// Translate
	// --- Changes the X,Y position of the rover based on the left and right wheel settings.
	// --- Param: elapsedTime - time since last update in seconds.
	void Translate(double elapsedTime);
	
};


