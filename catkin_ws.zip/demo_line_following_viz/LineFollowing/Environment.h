#pragma once
#include "OGL_header.h"
#include "Simulation.h"
#include "BMP.h"

class Environment
{
private:
	GLuint texture;
	GLuint textureWidth;
	GLuint textureHeight;
	BMP* image;

	Simulation* _sim;

	GLfloat p0[2];
	GLfloat p1[2];
	GLfloat p2[2];
	GLfloat p3[2];
	GLfloat p4[2];

	GLuint i0[2];
	GLuint i1[2];
	GLuint i2[2];
	GLuint i3[2];
	GLuint i4[2];
public:

	Environment(Simulation* sim);

	// CheckForLine
	// --- Checks environment texture image for line presence based on given parameters. Assumes sensor array contains 5 elements.
	// --- Param:	x - X position relative to the top-left corner of the environment image
	//				y - Y position relative to the top-left corner of the environment image
	//				theta - Orientation around axis through screen
	//				offset - distance sensor line is constructed from x,y position
	//				width - spacing between sensor array elements
	//				sensorArray - array to return line indicators
	void CheckForLine(float x, float y, float theta, float offset, float width, bool* sensorArray);

	// Draw
	// --- Renders the loaded environment image to the screen 
	void Draw();

	GLuint Width();
	GLuint Height();	

private:

	// LoadImage
	// --- Attempts to load the given texture image file in BMP format.  Does not check for errors. Any errors are handled by BMP class. Also, sets texture width and height to the size of the loaded texture
	// --- Params: textureFile - Absolute or relative path to the image file. Note relative to current working directory.
	void LoadImage(std::string textureFile);
};